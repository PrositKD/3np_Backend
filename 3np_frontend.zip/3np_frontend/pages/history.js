import Link from 'next/link';
import Image from 'next/image'
import Layout from './layout/layout';
export default function History(){
    return(
        <>
        <Layout page="history">
        
        <h1>Here is your work history</h1>
   
       </Layout>
        </>
    )
}