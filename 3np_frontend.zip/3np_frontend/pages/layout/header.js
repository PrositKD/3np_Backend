import Image from 'next/image'
export default function Header(){
    return(
        <>
       <Image src="/agriculture.png" width={50}height={50}/> 
        </>
    )
}