export default function Footer(){
    return(
        <>
       <h6>This is footer</h6>
        </>
    )
}